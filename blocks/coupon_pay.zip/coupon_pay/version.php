<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2022041903;        // The current plugin version (Date: YYYYMMDDXX).
$plugin->requires  = 2022041200;        // Requires this Moodle version.
$plugin->component = 'block_coupon_pay'; // Full name of the plugin (used for diagnostics)
