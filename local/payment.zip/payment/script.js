const baseUrl = document.getElementById("baseUrl").value;
const userid = document.getElementById("userid");
const pay_username = document.getElementById("pay_username");
let callback_url = document.getElementById("callback_url");
const btnPayment = document.getElementById("btn-payment");
const new_registration_btn = document.querySelector(".btn1");
const login1 = document.querySelector(".login1");
const emailId = document.querySelector(".email-id");
const password = document.querySelector("#address");
const btnBack = document.getElementById("btn-back");
const registration_backBtn = document.getElementById(
  "new_registration_backBtn"
);

const isloggedin = document.querySelector("#isloggedin");
const cta = document.getElementById("cta");
const popUp = document.getElementById("pop-up");
const emailPayment = document.querySelector(".email-val");
const new_registration_cta = document.getElementById("new_registration_cta");
const new_registration_popUp = document.getElementById("new_registration");
const paymentpopup = document.getElementById("paymentpopup");
const ctapayment = document.getElementById("ctapayment");
const btnblue = document.getElementById("btnblue");
const btnback1 = document.getElementById("btn-back1");
// const btnback2 = document.getElementById("btn-back2");
const endresult = document.querySelector(".endresult");
const alertpopup = document.getElementById("alertpopup");
const ctaalert = document.getElementById("ctaalert");
// const newregistrationcontinue = document.getElementById(
//   "new_registrationcontinue"
// );
let islog = Number(isloggedin.value)

const loginForm = document.getElementById("loginForm");
const loginpopup = document.getElementById("loginpopup");
const loginError = document.getElementById("loginError");
const registrationForm = document.getElementById("registrationForm");
const registrationpopup = document.getElementById("registrationpopup");
const usernameError = document.getElementById("reg_username-error");
const firstnameError = document.getElementById("reg_firstname-error");
const lastnameError = document.getElementById("reg_lastname-error");
const emailError = document.getElementById("reg_email-error");  
const passwordError = document.getElementById("reg_password-error");

let emailIdValue;
// newregistrationcontinue.addEventListener("click", () => {
//   paymentpopup.classList.remove("slideout-animation");
//   ctapayment.classList.add("slidein-animation");
//   paymentpopup.style.display = "flex";
//   new_registration_back();
// });

// endresult.addEventListener("click", () => {
//   alertpopup.classList.remove("slideout-animation");
//   ctaalert.classList.add("slidein-animation");
//   alertpopup.style.display = "flex";
//   NewpaymentClosePopup();
//   closePopUpHandler();
//   setTimeout(() => {
//     handelalert();
//     window.location.href = "http://yislms.com/lms/course/view.php?id=2";
//   }, 1500);
// });


const handelalert = () => {
  alertpopup.classList.remove("slideout-animation");
  ctaalert.classList.add("slidein-animation");
  alertpopup.style.display = "none";
};

function showPopUpHandler() {
if(!islog){
  popUp.classList.remove("slideout-animation");
  cta.classList.add("slidein-animation");
  popUp.style.display = "flex";
}else{
  Newpaymentpopup()
}
  

}

function new_registration_Popup() {
  new_registration_popUp.classList.remove("slideout-animation");
  new_registration_cta.classList.add("slidein-animation");
  new_registration_popUp.style.display = "flex";
  closePopUpHandler();
}

function new_registration_back() {
  new_registration_cta.classList.remove("slidein-animation");
  new_registration_popUp.classList.add("slideout-animation");
  new_registration_popUp.style.display = "none";
}

function Newpaymentpopup() {
  paymentpopup.classList.remove("slideout-animation");
  ctapayment.classList.add("slidein-animation");
  paymentpopup.style.display = "flex";
  closePopUpHandler();
  emailPayment.value = emailId.value;
}
function NewpaymentClosePopup() {
  paymentpopup.classList.remove("slideout-animation");
  ctapayment.classList.add("slidein-animation");
  paymentpopup.style.display = "none";
}

function closePopUpHandler() {
 
  cta.classList.remove("slidein-animation");
  popUp.classList.add("slideout-animation");
  popUp.style.display = "none";
}

const handelLogin = () => {
  new_registration_back();
  // showPopUpHandler();
  popUp.classList.remove("slideout-animation");
  cta.classList.add("slidein-animation");
  popUp.style.display = "flex";
};

const loginSuccessPopup = () => {
  closePopUpHandler();
  loginpopup.classList.remove("slideout-animation");
  loginpopup.classList.add("slidein-animation");
  loginpopup.style.display = "flex";
};

const closeLoginSuccessPopup = () => {
  loginpopup.style.display = "none";
  Newpaymentpopup();
};
const registrationSuccessPopup = () => {
  closePopUpHandler();
  new_registration_back();
  registrationpopup.classList.remove("slideout-animation");
  registrationpopup.classList.add("slidein-animation");
  registrationpopup.style.display = "flex";
};

const closeregistrationSuccessPopup = () => {
  registrationpopup.classList.remove("slidein-animation");
  registrationpopup.classList.add("slideout-animation");
  registrationpopup.style.display = "none";
  Newpaymentpopup();
};

// Registration Username validation
function validateUsername(username) {
  const usernameRegex = /^[a-zA-Z0-9]{3,16}$/;
  if (!usernameRegex.test(username)) {
    usernameError.innerText = "Username must be alphanumeric";
    return false;
  } else {
    // Username is valid
    usernameError.innerText = "";
    return true;
  }
}

// Registration Firstname | Lastname validation
const validateName = (firstName, lastName) => {
  const nameRegex = /^[a-zA-Z0-9]{3,16}$/;
  if (!nameRegex.test(firstName)) {
    firstnameError.innerText = "Firstname must be alphanumeric";
  } else {
    // Firstname is valid
    firstnameError.innerText = "";
  }
  if (!nameRegex.test(lastName)) {
    lastnameError.innerText = "Lastname must be alphanumeric";
  } else {
    // Lastname is valid
    lastnameError.innerText = "";
  }
  if (
    firstnameError.innerText.length > 0 ||
    lastnameError.innerText.length > 0
  ) {
    return false;
  }
  return true;
};

// Registration Password validation
function validatePassword(password) {
  const passwordRegex =
    /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
  let errorMessage = "";
  if (!passwordRegex.test(password)) {
    errorMessage = "Password must contain at least:\n";
    if (!/[A-Z]/.test(password)) errorMessage += "- One uppercase letter\n";
    if (!/[a-z]/.test(password)) errorMessage += "- One lowercase letter\n";
    if (!/[0-9]/.test(password)) errorMessage += "- One number\n";
    if (!/[#?!@$%^&*-]/.test(password))
      errorMessage += "- One special character\n";
    passwordError.innerText = errorMessage;
    return false;
  } else {
    // Password is valid
    passwordError.innerText = "";
    return true;
  }
}

new_registration_btn.addEventListener("click", new_registration_Popup);
btnPayment.addEventListener("click", showPopUpHandler);
btnBack.addEventListener("click", (e)=>{
e.preventDefault()
  closePopUpHandler()
});
registration_backBtn.addEventListener("click", new_registration_back);
// btnblue.addEventListener("click", Newpaymentpopup);
login1.addEventListener("click", handelLogin);
btnback1.addEventListener("click", NewpaymentClosePopup);

$("#loginForm").on("submit", function (event) {
  event.preventDefault();

  let formData = $(this).serializeArray();
  let formType = formData[2].value;
  formData.pop();

  $.ajax({
    url: baseUrl + "/local/payment/index.php",
    method: "post",
    data: { formData, formType },
    dataType: "json",
    async: true,
    success: function (resp) {
      if (resp.login) {
        islog = 1;
        loginError.innerText = "";
        userid.value = resp.userid;
        pay_username.value = resp.username
        callback_url.value += "&userid=" + userid.value;
        loginSuccessPopup();
        setTimeout(() => {
          closeLoginSuccessPopup();
        }, 3000);
      } else if (resp.error) {
        loginError.innerText = resp.error;
      }
    },
    error: function (xhr, status, error) {
      console.log("Error:", error);
    },
  });
});

$("#registrationForm").on("submit", function (event) {
  event.preventDefault();
  let formData = $(this).serializeArray();
  const data = {};
  formData.forEach((item) => {
    data[item.name] = item.value;
  });
  let error = [];
  if (!validateUsername(data.username)) {
    error.push("username");
  }
  if (!validateName(data.firstname, data.lastname)) {
    error.push("name");
  }
  if (!validatePassword(data.password)) {
    error.push("password");
  }
  if (error.length == 0) {
    $.ajax({
      url: baseUrl + "/local/payment/index.php",
      method: "post",
      data: data,
      dataType: "json",
      async: true,
      success: function (resp) {
        if (resp.username_error) {
          usernameError.innerText = "Username already exists!";
        } else {
          usernameError.innerText = "";
        }
        if (resp.email_error) {
          emailError.innerText = "Email ID already exists!";
        } else {
          emailError.innerText = "";
        }
        if (resp.created) {
        
          userid.value = resp.userid;
          pay_username.value = resp.username
          callback_url.value += "&userid=" + userid.value;
          registrationSuccessPopup();
          setTimeout(() => {
            closeregistrationSuccessPopup();
          }, 3000);
        }
      },
      error: function (xhr, status, error) {
        console.log("Error:", error);
      },
    });
  }
});
