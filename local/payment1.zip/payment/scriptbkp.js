const baseUrl = document.getElementById("baseUrl").value;
const btnPayment = document.getElementById("btn-payment");
const new_registration_btn = document.querySelector(".btn1");
const login1 = document.querySelector(".login1");
const emailId = document.querySelector(".email-id");
const password = document.querySelector("#address");
const btnBack = document.getElementById("btn-back");
const registration_backBtn = document.getElementById(
  "new_registration_backBtn"
);
const cta = document.getElementById("cta");
const popUp = document.getElementById("pop-up");
const emailPayment = document.querySelector(".email-val");
const new_registration_cta = document.getElementById("new_registration_cta");
const new_registration_popUp = document.getElementById("new_registration");
const paymentpopup = document.getElementById("paymentpopup");
const ctapayment = document.getElementById("ctapayment");
const btnblue = document.getElementById("btnblue");
const btnback1 = document.getElementById("btn-back1");
const endresult = document.querySelector(".endresult");
const alertpopup = document.getElementById("alertpopup");
const ctaalert = document.getElementById("ctaalert");
const newregistrationcontinue = document.getElementById(
  "new_registrationcontinue"
);
const loginForm = document.getElementById("loginForm");

let emailIdValue;
newregistrationcontinue.addEventListener("click", () => {
  paymentpopup.classList.remove("slideout-animation");
  ctapayment.classList.add("slidein-animation");
  paymentpopup.style.display = "flex";
  new_registration_back();
});

endresult.addEventListener("click", () => {
  alertpopup.classList.remove("slideout-animation");
  ctaalert.classList.add("slidein-animation");
  alertpopup.style.display = "flex";
  NewpaymentClosePopup();
  closePopUpHandler();
  setTimeout(() => {
    handelalert();
    window.location.href = "http://yislms.com/lms/course/view.php?id=2";
  }, 1500);
});

const handelalert = () => {
  alertpopup.classList.remove("slideout-animation");
  ctaalert.classList.add("slidein-animation");
  alertpopup.style.display = "none";
};

function showPopUpHandler() {
  popUp.classList.remove("slideout-animation");
  cta.classList.add("slidein-animation");
  popUp.style.display = "flex";
}

function new_registration_Popup() {
  new_registration_popUp.classList.remove("slideout-animation");
  new_registration_cta.classList.add("slidein-animation");
  new_registration_popUp.style.display = "flex";
  closePopUpHandler();
}

function Newpaymentpopup() {
  if (emailId.value && password.value) {
    paymentpopup.classList.remove("slideout-animation");
    ctapayment.classList.add("slidein-animation");
    paymentpopup.style.display = "flex";
    closePopUpHandler();
    emailPayment.value = emailId.value;
  } else {
  }
}
function NewpaymentClosePopup() {
  paymentpopup.classList.remove("slideout-animation");
  ctapayment.classList.add("slidein-animation");
  paymentpopup.style.display = "none";
}

function closePopUpHandler() {
  cta.classList.remove("slidein-animation");
  popUp.classList.add("slideout-animation");
  popUp.style.display = "none";
}
function new_registration_back() {
  new_registration_cta.classList.remove("slidein-animation");
  new_registration_popUp.classList.add("slideout-animation");
  new_registration_popUp.style.display = "none";
}

const handelLogin = () => {
  new_registration_back();
  showPopUpHandler();
};

new_registration_btn.addEventListener("click", new_registration_Popup);
btnPayment.addEventListener("click", showPopUpHandler);
btnBack.addEventListener("click", closePopUpHandler);
registration_backBtn.addEventListener("click", new_registration_back);
btnblue.addEventListener("click", Newpaymentpopup);
login1.addEventListener("click", handelLogin);
btnback1.addEventListener("click", NewpaymentClosePopup);



$("#loginForm").on('submit', function (event) {
  event.preventDefault();

  let formData = $(this).serializeArray();
  let formType = formData[2].value;
  formData.pop();

  $.ajax({
    url: baseUrl + '/local/payment/index.php',
    method: "post",
    data: { formData, formType },
    dataType: "json",
    async: true,
    success: function (resp) {
      console.log(resp);
    },
    error: function (xhr, status, error) {
      console.log("Error:", error);
    }
  })
})
