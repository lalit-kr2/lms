<?php
$string['pluginname'] = 'Payment Gate';
?>