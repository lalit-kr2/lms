<?php

require_once("../../config.php");
require_once("../../lib/moodlelib.php");
require_once("../../user/lib.php");

$courseid = optional_param('id', 0, PARAM_INT);
$formType = optional_param('formType', "", PARAM_TEXT);

if ($formType === 'login') {
    $formData = $_POST['formData'];
    foreach ($formData as $data) {
        ${$data['name']} = $data['value'];
    }
    $response = ['login' => false, 'error' => 'Invalid Credentials!'];

    if ($user = authenticate_user_login($username, $password)) {
        $response['login'] = true;
        $response['userid'] = $user->id;
        $response['username'] = "$user->firstname";
        unset($response['error']);
        complete_user_login($user);
    }

    echo json_encode($response);
    exit();
} else if ($formType === 'registration') {
    $username = optional_param('username', '', PARAM_TEXT);
    $firstname = optional_param('firstname', '', PARAM_TEXT);
    $lastname = optional_param('lastname', '', PARAM_TEXT);
    $email = optional_param('email', '', PARAM_TEXT);
    $password = optional_param('password', '', PARAM_TEXT);
    $phone = optional_param('phone', '', PARAM_INT);
    
    $data = [];
    if ($DB->record_exists('user', ['username' => $username])) {
        $data['username_error'] = true;
    }
    if ($DB->record_exists('user', ['email' => $email])) {
        $data['email_error'] = true;
    }
    if (empty($data)) {
        $obj = new stdClass();
        $obj->username = $username;
        $obj->firstname = $firstname;
        $obj->lastname = $lastname;
        $obj->email = $email;
        $obj->confirmed = 1;
        $obj->mnethostid = 1;
        $obj->password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
        $obj->phone1 = $phone;

        $id = user_create_user($obj);
        $user = $DB->get_record('user', ['id' => $id]);
        complete_user_login($user);

        if ($id) {
            $data['created'] = true;
            $data['userid'] = $id;
            $data['username'] = "$firstname";
        }
    }
    echo json_encode($data);
    die();
}

$coursename = $DB->get_field('course', 'fullname', ['id' => $courseid]);
$amount = $DB->get_record_sql("SELECT mcfd.value FROM {customfield_data} mcfd JOIN {customfield_field} mcff ON mcfd.fieldid = mcff.id WHERE mcff.shortname = 'price' AND mcfd.instanceid = $courseid")->value;

$templatecontext = [
    'output' => $OUTPUT,
    'courseid' => $courseid,
    'coursename' => $coursename,
    'amount' => $amount,
    'isloggedin' => isloggedin()
];

echo $OUTPUT->render_from_template("local_payment/index", $templatecontext);
