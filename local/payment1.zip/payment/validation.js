// // Selecting the registration form fields
// document.addEventListener("load", function () {
//   const reg_username = document.getElementById("reg_username");
//   const reg_firstname = document.getElementById("reg_firstname");
//   const reg_lastname = document.getElementById("reg_lastname");
//   const reg_email = document.getElementById("reg_email");
//   const reg_password = document.getElementById("reg_password");
//   const reg_phone = document.getElementById("reg_phone");

//   function validateUsername(username) {
//     const usernameError = document.getElementById("reg_username-error");
//     const usernameRegex = /^[a-zA-Z0-9]{3,16}$/;
//     if (!usernameRegex.test(username)) {
//       usernameError.innerText =
//         "Username must be alphanumeric and must contain 3-16 characters";
//     } else {
//       // Username is valid
//       usernameError.style.display = "none";
//     }
//   };
//   reg_username.addEventListener("keypress", (e)=>{
//     console.log(e);
//   });
//   function validateNumber(e) {
//     const pattern = /^[0-9]$/;

//     return pattern.test(e.key )
// }
//   const validateName = (nameField) => {
//     const name = nameField.value;
//     const nameRegex = /^[a-zA-Z0-9]{3,16}$/;
//     if (!nameRegex.test(name)) {
//       // Handle invalid name
//     } else {
//       // Name is valid
//     }
//   };

//   function validateEmail() {
//     const email = emailField.value;
//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       // Handle invalid email
//     } else {
//       // Email is valid
//     }
//   };

//   function validatePassword() {
//     const password = passwordField.value;
//     const passwordRegex =
//       /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
//     if (!passwordRegex.test(password)) {
//       // Handle invalid password
//     } else {
//       // Password is valid
//     }
//   };

//   function validatePhone() {
//     const phone = phoneField.value;
//     const phoneRegex = /^\d{10}$/;
//     if (!phoneRegex.test(phone)) {
//       // Handle invalid phone number
//     } else {
//       // Phone number is valid
//     }
//   };

//   // Adding onchange event listeners
  
//   // firstnameField.addEventListener('change', () => validateName(firstnameField));
//   // lastnameField.addEventListener('change', () => validateName(lastnameField));
//   // emailField.addEventListener('change', validateEmail);
//   // passwordField.addEventListener('change', validatePassword);
//   // phoneField.addEventListener('change', validatePhone);
// });
