<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version     = 2023092002;
// $plugin->requires    = 2022041900; // Moode 4.0+.
$plugin->component   = 'local_payment';

