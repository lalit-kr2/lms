<?php

require_once("../../config.php");
require_once("$CFG->dirroot/lib/enrollib.php");

global $DB;

$orderid = required_param('id', PARAM_TEXT);
$status = required_param('status', PARAM_TEXT);
$amount = required_param('amount', PARAM_TEXT);
$message = required_param('message', PARAM_TEXT);
$courseid = required_param('courseid', PARAM_INT);
$userid = required_param('userid', PARAM_INT);

$currency = 'SAR';

$obj = new stdClass();
$obj->userid = $userid;
$obj->courseid = $courseid;
$obj->orderid = $orderid;
$obj->status = $status;
$obj->amount = $amount;
$obj->currency = $amount;
$obj->message = $message;
$obj->timecreated = time();
$obj->timemodified = time();

if (!$DB->record_exists('new_payment', ['userid' => $userid, 'courseid' => $courseid])) {
    $id = $DB->insert_record('new_payment', $obj);

    $studentRoleId = $DB->get_field('role', 'id', ['shortname' => 'student']);

    if ($id) {
        enrol_try_internal_enrol($courseid, $userid, $studentRoleId);

        redirect("$CFG->wwwroot/course/view.php?id=$courseid", 'User successfully enrolled in the course!');
    } else {
        redirect("$CFG->wwwroot/my", 'Something Went Wrong! Try again');
    }
} else {
    redirect("$CFG->wwwroot/my", 'User already enrolled in the course!');
}
